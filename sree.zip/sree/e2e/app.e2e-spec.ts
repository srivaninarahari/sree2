import { SreePage } from './app.po';

describe('sree App', () => {
  let page: SreePage;

  beforeEach(() => {
    page = new SreePage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
